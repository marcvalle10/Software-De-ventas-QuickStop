import View.Grafico;

public class Main {
    public static void main(String[] args) {

        Grafico grafico=new Grafico();
        grafico.inicio();

    }
}